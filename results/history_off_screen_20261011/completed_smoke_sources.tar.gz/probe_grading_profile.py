import importlib.util
import json
import sys
from pathlib import Path

import httpx
from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Route
from starlette.testclient import TestClient

async def headers(request):
    return JSONResponse({'accept_encoding': request.headers['accept-encoding']})

app = Starlette(routes=[Route('/', headers)])
with httpx.Client() as client:
    ordinary_header = client.headers['accept-encoding']
with TestClient(app) as client:
    response = client.get('/')
assert response.status_code == 200
profile = Path('/opt/provenance-audit/sandbox-profile.txt').read_text().strip()
origins = {name: spec.origin if (spec := importlib.util.find_spec(name)) else None
           for name in ('httpx', 'httpcore', 'h11', 'brotli', 'brotlicffi', 'httpbin', 'pytest_httpbin', 'flask')}
assert origins['h11'] is not None
assert origins['flask'] is not None
if profile == 'framework':
    assert all(origins[name] is None for name in ('brotli', 'brotlicffi', 'httpbin', 'pytest_httpbin'))
    assert ordinary_header == response.json()['accept_encoding'] == 'gzip, deflate'
print(json.dumps({'profile': profile, 'python': sys.version, 'origins': origins,
                  'ordinary_httpx_accept_encoding': ordinary_header,
                  'asgi_status': response.status_code, 'asgi_accept_encoding': response.json()['accept_encoding']}))
