import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument('--runner', type=Path, required=True)
parser.add_argument('--controls', type=Path, required=True)
parser.add_argument('--tasks', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
spec = importlib.util.spec_from_file_location('paired_runner', args.runner)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
runner.load_sdk()
task_data = next(json.loads(line) for line in args.tasks.read_text().splitlines() if json.loads(line)['instance_id'] == 'rich_3454')
task = SimpleNamespace(FAIL_TO_PASS=(), PASS_TO_PASS=(), test_patch=task_data['test_patch'])
negative_path = args.controls / 'controls/unpatched/evidence/rich_3454/junit.xml'
reference_path = args.controls / 'controls/reference/evidence/rich_3454/junit.xml'
xml = negative_path.read_text()
root = ET.fromstring(xml)
failed = next(tc for tc in root.findall('.//testcase') if tc.find('failure') is not None)
qualified_failure = failed.attrib['classname'].replace('.', '/') + '.py::' + failed.attrib['name']
rows = []
def check(name, content, expected, current=task, clean=True, kind='unpatched'):
    valid, reason = runner.junit_check(content, current, kind, reference_clean=clean)
    assert valid is expected, (name, valid, reason)
    rows.append({'scenario': name, 'valid': valid, 'reason': reason})

def mutated(change):
    copy = ET.fromstring(xml)
    change(copy)
    return ET.tostring(copy, encoding='unicode')

check('actual_changed_parameter_assertion', xml, True)
check('reference_required', xml, False, clean=False)
check('unchanged_sdk_reference', reference_path.read_text(), True, kind='reference')
check('unchanged_sdk_rejects_actual_negative', xml, False, kind='model')
check('unrelated_module_failure', mutated(lambda r: next(tc for tc in r.findall('.//testcase') if tc.find('failure') is not None).set('classname', 'tests.test_unrelated')), False)
check('no_negative_failure', mutated(lambda r: next(tc for tc in r.findall('.//testcase') if tc.find('failure') is not None).remove(next(r.iter('failure')))), False)
check('explicit_fail_to_pass_stays_strict', xml, False, SimpleNamespace(FAIL_TO_PASS=('tests/test_highlighter.py::test_wrong_type',), PASS_TO_PASS=(), test_patch=task.test_patch))
check('pass_to_pass_failure_stays_rejected', xml, False, SimpleNamespace(FAIL_TO_PASS=(), PASS_TO_PASS=(qualified_failure,), test_patch=task.test_patch))
check('required_skip_stays_rejected', mutated(lambda r: ET.SubElement(next(tc for tc in r.findall('.//testcase') if tc.attrib.get('name') == 'test_wrong_type'), 'skipped')), False)
check('unscoped_setup_error_stays_rejected', mutated(lambda r: setattr(next(r.iter('failure')), 'tag', 'error')), False)
args.output.write_text(json.dumps({'runner_sha256': hashlib.sha256(args.runner.read_bytes()).hexdigest(), 'negative_junit_sha256': hashlib.sha256(negative_path.read_bytes()).hexdigest(), 'reference_junit_sha256': hashlib.sha256(reference_path.read_bytes()).hexdigest(), 'scenarios': rows, 'all_expected_results_observed': True}, indent=2) + '\n')
print(json.dumps(rows, indent=2))
