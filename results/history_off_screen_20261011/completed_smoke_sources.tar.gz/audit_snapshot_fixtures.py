import argparse
import hashlib
import json
import re
import tarfile
from pathlib import Path, PurePosixPath

parser = argparse.ArgumentParser()
parser.add_argument('--data-root', type=Path, required=True)
parser.add_argument('--plan', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
plan = json.loads(args.plan.read_text())
tasks = {row['instance_id']: row for line in (args.data_root / 'tasks.jsonl').read_text().splitlines()
         if (row := json.loads(line))['instance_id'] in plan['task_ids']}
records = []
for task_id in plan['task_ids']:
    snapshot = args.data_root / 'snapshots' / (task_id + '.tgz')
    with snapshot.open('rb') as stream:
        archive_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    declarations, conftests, relevant_mentions = [], [], []
    with tarfile.open(snapshot, 'r|gz') as archive:
        for member in archive:
            parts = PurePosixPath(member.name).parts
            if not member.isfile() or '.git' in parts:
                continue
            name = parts[-1]
            is_declaration = name in {'pyproject.toml', 'pytest.ini', 'setup.cfg', 'setup.py'} or (
                name.startswith('requirements') and name.endswith('.txt'))
            is_test = 'tests' in parts and name.endswith('.py')
            if not (is_declaration or is_test):
                continue
            content = archive.extractfile(member).read()
            text = content.decode('utf-8', errors='replace')
            item = {'path': member.name, 'sha256': hashlib.sha256(content).hexdigest()}
            if is_declaration:
                declarations.append({**item, 'text': text})
            if is_test and name == 'conftest.py':
                conftests.append({**item, 'text': text})
            mentions = [{'line': n, 'text': line} for n, line in enumerate(text.splitlines(), 1)
                        if re.search(r'httpbin|pytest_httpbin|brotlicffi|\bbrotli\b', line, re.I)]
            if mentions:
                relevant_mentions.append({**item, 'mentions': mentions})
    test_patch = tasks[task_id].get('test_patch', '')
    gold_mentions = [line for line in test_patch.splitlines()
                     if re.search(r'httpbin|pytest_httpbin|brotlicffi|\bbrotli\b', line, re.I)]
    record = {'task_id': task_id, 'base_commit': tasks[task_id]['base_commit'],
              'snapshot': str(snapshot), 'snapshot_sha256': archive_sha,
              'snapshot_bytes': snapshot.stat().st_size, 'declarations': declarations,
              'conftests': conftests, 'dependency_mentions': relevant_mentions,
              'gold_test_dependency_mentions': gold_mentions,
              'framework_profile_eligible': not relevant_mentions and not gold_mentions}
    records.append(record)
    print(task_id, 'framework_eligible=', record['framework_profile_eligible'], flush=True)
args.output.write_text(json.dumps({'source': 'Direct streaming read of exact copied task snapshots and public test patches; no tests executed or files changed.',
                                   'task_ids': plan['task_ids'], 'records': records}, indent=2) + '\n')
