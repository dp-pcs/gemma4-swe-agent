import argparse
import dataclasses
import importlib.util
import json
import xml.etree.ElementTree as ET
from pathlib import Path

from swegemma.models import load_tasks

parser = argparse.ArgumentParser()
parser.add_argument('--runner', type=Path, required=True)
parser.add_argument('--data-root', type=Path, required=True)
parser.add_argument('--current-xml', type=Path, required=True)
parser.add_argument('--old-xml', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
spec = importlib.util.spec_from_file_location('measured_runner', args.runner)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
runner.load_sdk()
task = next(row for row in load_tasks(args.data_root / 'tasks.jsonl') if row.instance_id == 'fastapi_14356')
current = args.current_xml.read_text()
rows = []

def check(name, xml, expected, kind='unpatched', chosen_task=task):
    actual, reason = runner.junit_check(xml, chosen_task, kind)
    assert actual is expected, (name, actual, reason)
    rows.append({'scenario': name, 'trusted': actual, 'reason': reason})

check('Actual fixed-header gold regression with paired snapshot teardown', current, True)
check('Actual unpatched assertions cannot be a passing reference', current, False, 'reference')
check('Prior Brotli-induced unrelated snapshot errors remain rejected', args.old_xml.read_text(), False)
root = ET.fromstring(current)
error_case = next(tc for tc in root.findall('.//testcase') if tc.find('error') is not None)
key = (error_case.get('classname'), error_case.get('name'))
for suite in root.findall('.//testsuite'):
    for tc in list(suite):
        if tc.tag == 'testcase' and (tc.get('classname'), tc.get('name')) == key and tc.find('failure') is not None:
            suite.remove(tc)
check('Snapshot teardown without paired assertion remains rejected', ET.tostring(root, encoding='unicode'), False)
root = ET.fromstring(current)
next(tc.find('error') for tc in root.findall('.//testcase') if tc.find('error') is not None).set('message', 'failed on teardown with unrelated fixture error')
check('Generic teardown error remains rejected', ET.tostring(root, encoding='unicode'), False)
root = ET.fromstring(current)
for tc in root.findall('.//testcase'):
    if (tc.get('classname'), tc.get('name')) == key:
        tc.set('classname', 'tests.unrelated_module')
check('Same test name in unchanged module remains rejected', ET.tostring(root, encoding='unicode'), False)
root = ET.fromstring(current)
required_pass = next(tc for tc in root.findall('.//testcase') if tc.get('name') == 'test_query_pass_extra_single')
ET.SubElement(required_pass, 'skipped')
check('Required gold test cannot be skipped', ET.tostring(root, encoding='unicode'), False)
explicit_task = dataclasses.replace(task, FAIL_TO_PASS=['test_query_pass_extra_list'],
                                    PASS_TO_PASS=['test_header_pass_extra_list'])
check('Explicit PASS_TO_PASS assertion failure remains rejected', current, False, chosen_task=explicit_task)
args.output.write_text(json.dumps({'scenarios': rows, 'source': 'Actual captured JUnit and real current SDK selectors/validator; no scoring SDK edits or model requests.'}, indent=2) + '\n')
print(json.dumps(rows, indent=2))
